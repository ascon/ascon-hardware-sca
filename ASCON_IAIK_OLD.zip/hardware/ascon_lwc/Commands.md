python3 gen_shared.py --design ascon_v1.toml --folder ./KAT/v1
python3 gen_shared.py --design ascon_v2.toml --folder ./KAT/v2
python3 gen_shared.py --design ascon_v3.toml --folder ./KAT/v3
python3 gen_shared.py --design ascon_v4.toml --folder ./KAT/v4

